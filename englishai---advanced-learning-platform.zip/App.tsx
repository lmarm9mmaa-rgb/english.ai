
import React, { useState, useEffect, useRef } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import PlacementTest from './components/PlacementTest';
import WritingLab from './components/WritingLab';
import VocabularySystem from './components/VocabularySystem';
import StudyPlanGenerator from './components/StudyPlanGenerator';
import { db } from './services/dbService';
import { 
  Mic, 
  BookOpen, 
  ArrowLeft, 
  Loader2, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Volume2, 
  Mail, 
  Lock,
  UserPlus,
  LogIn
} from 'lucide-react';
import { UserProfile, Level } from './types';
import { GoogleGenAI, Modality } from '@google/genai';
import { encodeAudio, decodeAudio, decodeAudioData } from './services/geminiService';

const SpeakingCoach = () => {
  const [status, setStatus] = useState<'idle' | 'connecting' | 'active' | 'error'>('idle');
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const sessionRef = useRef<any>(null);
  const audioContextsRef = useRef<{
    input: AudioContext;
    output: AudioContext;
    stream: MediaStream;
    processor: ScriptProcessorNode;
    sources: Set<AudioBufferSourceNode>;
  } | null>(null);
  const nextStartTimeRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (audioContextsRef.current) {
      const { stream, sources, processor, input, output } = audioContextsRef.current;
      stream.getTracks().forEach(track => track.stop());
      sources.forEach(source => { try { source.stop(); } catch(e) {} });
      if (processor) processor.disconnect();
      input.close();
      output.close();
      audioContextsRef.current = null;
    }
    nextStartTimeRef.current = 0;
    setStatus('idle');
  };

  const startSession = async () => {
    setStatus('connecting');
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new AudioContext({ sampleRate: 16000 });
      const outputCtx = new AudioContext({ sampleRate: 24000 });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const sources = new Set<AudioBufferSourceNode>();

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus('active');
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
              const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmData = new Uint8Array(int16.buffer);
              
              sessionPromise.then((session) => {
                session.sendRealtimeInput({
                  media: {
                    data: encodeAudio(pcmData),
                    mimeType: 'audio/pcm;rate=16000',
                  },
                });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
            
            if (audioContextsRef.current) {
              audioContextsRef.current.processor = scriptProcessor;
            }
          },
          onmessage: async (message) => {
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const audioBuffer = await decodeAudioData(
                decodeAudio(base64Audio),
                outputCtx,
                24000,
                1
              );
              const source = outputCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputCtx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sources.add(source);
              source.onended = () => sources.delete(source);
            }

            if (message.serverContent?.interrupted) {
              sources.forEach(s => { try { s.stop(); } catch(e) {} });
              sources.clear();
              nextStartTimeRef.current = 0;
            }

            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setMessages(prev => [...prev, { role: 'user', text }]);
            }
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setMessages(prev => [...prev, { role: 'model', text }]);
            }
          },
          onerror: (e) => {
            console.error('Live API Error:', e);
            setError('حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.');
            stopSession();
          },
          onclose: () => {
            stopSession();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } },
          },
          systemInstruction: 'You are an encouraging English speaking coach named Alex. Help the user practice English by having a natural conversation. Keep your responses concise and correct their mistakes gently.',
        },
      });

      sessionRef.current = await sessionPromise;
      audioContextsRef.current = { input: inputCtx, output: outputCtx, stream, processor: null as any, sources };

    } catch (err: any) {
      console.error('Mic Access Error:', err);
      setStatus('error');
      setError('لا يمكن الوصول إلى الميكروفون. يرجى التأكد من منح الأذونات اللازمة.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[650px] bg-white rounded-[3rem] shadow-xl border border-indigo-50 flex flex-col relative overflow-hidden">
      <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-white z-10">
        <div className="flex items-center gap-4">
          <div className={`w-3 h-3 rounded-full ${status === 'active' ? 'bg-green-500 animate-pulse' : 'bg-slate-300'}`} />
          <div>
            <h2 className="text-2xl font-bold text-slate-800">مدرب المحادثة الذكي</h2>
            <p className="text-sm text-slate-500">{status === 'active' ? 'متصل الآن' : 'بانتظار بدء الجلسة'}</p>
          </div>
        </div>
        {status === 'active' && (
          <button 
            onClick={stopSession}
            className="p-3 bg-red-50 text-red-600 rounded-2xl hover:bg-red-100 transition-all flex items-center gap-2 font-bold"
          >
            <XCircle className="w-5 h-5" />
            إنهاء الجلسة
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-4 bg-slate-50/50" ref={scrollRef}>
        {messages.length === 0 && status !== 'active' && (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-sm mx-auto">
            <div className="w-24 h-24 bg-indigo-600 rounded-[2rem] flex items-center justify-center mb-6 shadow-xl shadow-indigo-100">
              <Mic className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">ابدأ التحدث بالإنجليزية</h3>
            <p className="text-slate-500">تحدث مع Alex لتحسين مهاراتك اللغوية. سيقوم بتصحيح نطقك وقواعدك فورياً.</p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl text-left ${
              msg.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-bl-none' 
                : 'bg-white text-slate-800 border border-slate-100 rounded-br-none shadow-sm'
            }`} dir="ltr">
              <p className="font-medium">{msg.text}</p>
            </div>
          </div>
        ))}

        {status === 'active' && (
          <div className="flex justify-center py-4">
            <div className="flex gap-1">
              {[1, 2, 3].map(i => (
                <div key={i} className="w-2 h-8 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.1}s` }} />
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="p-8 bg-white border-t border-slate-100">
        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-2xl flex items-center gap-3 font-medium">
            <AlertTriangle className="w-5 h-5" />
            <span>{error}</span>
          </div>
        )}

        <div className="flex justify-center">
          {status === 'idle' || status === 'error' ? (
            <button 
              onClick={startSession}
              className="px-12 py-5 bg-indigo-600 text-white rounded-[2rem] text-xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center gap-3 transform hover:scale-105"
            >
              <Mic className="w-6 h-6" />
              ابدأ التحدث الآن
            </button>
          ) : status === 'connecting' ? (
            <div className="flex items-center gap-3 text-indigo-600 font-bold text-lg">
              <Loader2 className="w-6 h-6 animate-spin" />
              جاري إنشاء اتصال آمن...
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
               <div className="text-indigo-600 font-bold flex items-center gap-2">
                 <Volume2 className="w-5 h-5" />
                 تحدث الآن... Alex يستمع إليك
               </div>
               <p className="text-xs text-slate-400">يمكنك مقاطعة المدرب في أي وقت</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [onboardingStep, setOnboardingStep] = useState<'LOGIN' | 'PROFILE' | 'PLACEMENT' | 'COMPLETED'>('LOGIN');
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Auth Form State
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);

  useEffect(() => {
    const currentUser = db.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setOnboardingStep(currentUser.isOnboarded ? 'COMPLETED' : 'PROFILE');
      
      // Persistence: Restore last active tab
      const savedTab = db.getActiveTab(currentUser.email);
      if (savedTab) setActiveTab(savedTab);
    }
  }, []);

  useEffect(() => {
    if (user) {
      db.saveUser(user);
      // Persistence: Always save the active tab when it changes
      db.saveActiveTab(user.email, activeTab);
    }
  }, [user, activeTab]);

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setIsAuthLoading(true);

    setTimeout(() => {
      if (isSignUp) {
        if (password.length < 6) {
          setAuthError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
          setIsAuthLoading(false);
          return;
        }
        
        const existingUsers = db.getUsers();
        if (existingUsers.find(u => u.email === email)) {
          setAuthError('هذا الحساب موجود بالفعل');
          setIsAuthLoading(false);
          return;
        }

        const newUser: UserProfile = {
          email,
          name: '',
          level: 'Unknown',
          xp: 0,
          joinedAt: Date.now(),
          isOnboarded: false,
          hasTakenPlacementTest: false
        };
        db.saveUser(newUser);
        db.login(email);
        setUser(newUser);
        setOnboardingStep('PROFILE');
      } else {
        const users = db.getUsers();
        const found = users.find(u => u.email === email);
        if (found) {
          db.login(email);
          setUser(found);
          setOnboardingStep(found.isOnboarded ? 'COMPLETED' : 'PROFILE');
          
          const savedTab = db.getActiveTab(found.email);
          if (savedTab) setActiveTab(savedTab);
        } else {
          setAuthError('بيانات الدخول غير صحيحة');
        }
      }
      setIsAuthLoading(false);
    }, 1000);
  };

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim() || !user) return;
    
    const updatedUser = { ...user, name: nameInput };
    db.saveUser(updatedUser);
    setUser(updatedUser);
    setOnboardingStep('PLACEMENT');
  };

  const handleTestFinish = (level: Level, score: number) => {
    if (user) {
      const updatedUser: UserProfile = { 
        ...user, 
        level, 
        testScore: score, 
        hasTakenPlacementTest: true, 
        isOnboarded: true,
        xp: 500 
      };
      db.saveUser(updatedUser);
      setUser(updatedUser);
      setOnboardingStep('COMPLETED');
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    db.logout();
    setUser(null);
    setOnboardingStep('LOGIN');
    setEmail('');
    setPassword('');
    setNameInput('');
    setActiveTab('dashboard');
  };

  if (onboardingStep === 'LOGIN') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-['Noto_Sans_Arabic']" dir="rtl">
        <div className="max-w-md w-full bg-white rounded-[2.5rem] p-10 shadow-2xl shadow-indigo-100 border border-slate-100 animate-in fade-in duration-700">
          <div className="w-20 h-20 bg-indigo-600 rounded-[1.5rem] flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-indigo-200 transform hover:rotate-6 transition-transform">
            <BookOpen className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-800 mb-2 text-center">EnglishAI</h1>
          <p className="text-slate-500 mb-10 text-center font-medium leading-relaxed">منصتك المبتكرة لتعلم الإنجليزية</p>
          
          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {authError && (
              <div className="p-4 bg-red-50 text-red-600 rounded-2xl flex items-center gap-2 text-sm font-bold border border-red-100">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                {authError}
              </div>
            )}
            
            <div className="space-y-1">
              <label className="text-sm font-bold text-slate-500 px-2">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl py-4 pr-12 pl-4 outline-none transition-all font-medium"
                  placeholder="name@example.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-bold text-slate-500 px-2">كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl py-4 pr-12 pl-4 outline-none transition-all font-medium"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={isAuthLoading}
              className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isAuthLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : isSignUp ? (
                <><UserPlus className="w-5 h-5" /> إنشاء حساب جديد</>
              ) : (
                <><LogIn className="w-5 h-5" /> تسجيل الدخول</>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => { setIsSignUp(!isSignUp); setAuthError(null); }}
              className="text-indigo-600 font-bold hover:underline"
            >
              {isSignUp ? 'لديك حساب بالفعل؟ سجل دخولك' : 'ليس لديك حساب؟ سجل الآن'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (onboardingStep === 'PROFILE') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-['Noto_Sans_Arabic']" dir="rtl">
        <div className="max-w-md w-full bg-white rounded-[2.5rem] p-10 shadow-2xl shadow-indigo-100 border border-slate-100 animate-in fade-in slide-in-from-bottom-4">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">مرحباً بك في EnglishAI</h2>
            <p className="text-slate-500">تم إنشاء حسابك بنجاح! لنتعرف عليك</p>
          </div>
          <form onSubmit={handleProfileSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-500 px-1">الاسم الكامل</label>
              <input 
                type="text" 
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                className="w-full py-4 px-6 rounded-2xl bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white transition-all outline-none text-lg font-medium"
                required
                autoFocus
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all transform active:scale-95"
            >
              المتابعة لاختبار تحديد المستوى
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (onboardingStep === 'PLACEMENT') {
    return (
      <div className="min-h-screen bg-slate-50 p-4 font-['Noto_Sans_Arabic']" dir="rtl">
        <header className="max-w-4xl mx-auto flex items-center gap-4 py-8">
          <button onClick={() => setOnboardingStep('PROFILE')} className="p-3 bg-white rounded-xl shadow-sm hover:bg-slate-50">
            <ArrowLeft className="w-5 h-5 text-slate-500 rotate-180" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">اختبار تحديد المستوى الشامل</h1>
            <p className="text-sm text-slate-500">50 سؤالاً لقياس مهاراتك في القواعد والمفردات بدقة متناهية</p>
          </div>
        </header>
        <PlacementTest onFinish={handleTestFinish} />
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard user={user} />;
      case 'placement': return <PlacementTest onFinish={handleTestFinish} />;
      case 'writing': return <WritingLab userEmail={user?.email} />;
      case 'vocabulary': return <VocabularySystem />;
      case 'plan': return <StudyPlanGenerator currentLevel={user?.level} />;
      case 'speaking': return <SpeakingCoach />;
      default: return <Dashboard user={user} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab} user={user} onLogout={handleLogout}>
      {renderContent()}
    </Layout>
  );
};

export default App;
