
import { UserProfile, Word } from "../types";

const DB_KEYS = {
  USERS: 'english_ai_all_users', // Array of all users
  CURRENT_USER_EMAIL: 'english_ai_active_session',
  VOCAB: (email: string) => `english_ai_vocab_${email}`,
  PLAN: (email: string) => `english_ai_plan_${email}`,
  ACTIVE_TAB: (email: string) => `english_ai_active_tab_${email}`,
  WRITING_DRAFT: (email: string) => `english_ai_writing_draft_${email}`
};

export const db = {
  getUsers: (): UserProfile[] => {
    const data = localStorage.getItem(DB_KEYS.USERS);
    return data ? JSON.parse(data) : [];
  },
  
  saveUser: (user: UserProfile) => {
    const users = db.getUsers();
    const index = users.findIndex(u => u.email === user.email);
    if (index > -1) {
      users[index] = user;
    } else {
      users.push(user);
    }
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  },

  getCurrentUser: (): UserProfile | null => {
    const activeEmail = localStorage.getItem(DB_KEYS.CURRENT_USER_EMAIL);
    if (!activeEmail) return null;
    const users = db.getUsers();
    return users.find(u => u.email === activeEmail) || null;
  },

  login: (email: string): boolean => {
    const users = db.getUsers();
    const user = users.find(u => u.email === email);
    if (user) {
      localStorage.setItem(DB_KEYS.CURRENT_USER_EMAIL, email);
      return true;
    }
    return false;
  },

  logout: () => {
    localStorage.removeItem(DB_KEYS.CURRENT_USER_EMAIL);
  },

  getVocab: (email: string): Word[] => {
    const data = localStorage.getItem(DB_KEYS.VOCAB(email));
    return data ? JSON.parse(data) : [];
  },

  saveVocab: (email: string, words: Word[]) => {
    localStorage.setItem(DB_KEYS.VOCAB(email), JSON.stringify(words));
  },

  // Persisting App State for a consistent experience
  saveActiveTab: (email: string, tab: string) => {
    localStorage.setItem(DB_KEYS.ACTIVE_TAB(email), tab);
  },

  getActiveTab: (email: string): string | null => {
    return localStorage.getItem(DB_KEYS.ACTIVE_TAB(email));
  },

  saveWritingDraft: (email: string, draft: string) => {
    localStorage.setItem(DB_KEYS.WRITING_DRAFT(email), draft);
  },

  getWritingDraft: (email: string): string => {
    return localStorage.getItem(DB_KEYS.WRITING_DRAFT(email)) || '';
  }
};
