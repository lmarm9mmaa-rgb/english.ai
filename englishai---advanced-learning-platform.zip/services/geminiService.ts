
import { GoogleGenAI, Type } from "@google/genai";
import { WritingCorrection, StudyPlan, Question } from "../types";

// Always create a new instance right before making an API call to ensure it always uses the most up-to-date API key
export const getGeminiAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generatePlacementQuestions(count: number = 50): Promise<Question[]> {
  const ai = getGeminiAI();
  const randomSeed = Math.random().toString(36).substring(7);
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate exactly ${count} unique English placement test multiple-choice questions. 
    Seed: ${randomSeed}. 
    MANDATORY: Start from absolute Beginner (A1) and progressively increase difficulty every few questions until you reach Advanced (C2). 
    Mix grammar, vocabulary, and reading. 
    Return a JSON array of objects: { "id": number, "text": string, "options": [string, string, string, string], "correctAnswerIndex": number, "explanation": string, "category": string, "difficulty": "A1"|"A2"|"B1"|"B2"|"C1"|"C2" }.
    Use clear English for questions and Arabic for explanations.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            text: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswerIndex: { type: Type.INTEGER },
            explanation: { type: Type.STRING },
            category: { type: Type.STRING },
            difficulty: { type: Type.STRING }
          },
          required: ["id", "text", "options", "correctAnswerIndex", "explanation", "category", "difficulty"]
        }
      }
    },
  });
  
  try {
    const text = response.text || "[]";
    return JSON.parse(text);
  } catch (e) {
    console.error("Failed to parse AI questions:", e);
    return [];
  }
}

export async function generateStudyPlan(currentLevel: string, targetLevel: string, totalHoursPerDay: string): Promise<StudyPlan> {
  const ai = getGeminiAI();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Create a comprehensive 6-month English study plan for a student at level ${currentLevel} aiming for ${targetLevel}. They have ${totalHoursPerDay} available daily.
    Structure the plan into 6 phases (one per month). 
    For each phase, provide a representative week structure.
    MANDATORY: Include exactly how many minutes per day to spend on: Listening, Reading, Writing, and Speaking.
    MANDATORY: Recommend resources for each skill (Internal: 'Writing Lab', 'Speaking Coach', 'Vocabulary System'; External: 'BBC Learning English', 'Ted Talks', 'British Council', etc.).
    Format the response as JSON according to this structure:
    {
      "duration": "6 months",
      "phases": [
        {
          "month": 1,
          "goal": "string (Arabic)",
          "weeks": [
            {
              "week": 1,
              "dailyRoutine": { "listening": 20, "reading": 20, "writing": 10, "speaking": 10 },
              "resources": [{ "name": "string", "type": "internal|external", "description": "string (Arabic)" }],
              "tasks": [{ "day": "string (Arabic)", "activity": "string (Arabic)", "description": "string (Arabic)" }]
            }
          ]
        }
      ]
    }
    Use Arabic for all descriptive text.`,
    config: {
      responseMimeType: "application/json"
    },
  });
  const text = response.text || "{}";
  return JSON.parse(text);
}

export async function correctWriting(text: string): Promise<WritingCorrection> {
  const ai = getGeminiAI();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Correct the following English text: "${text}". 
    Identify grammar, spelling, and punctuation errors. Provide an explanation for each in Arabic. 
    Also provide a professional rephrase.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          originalText: { type: Type.STRING },
          correctedText: { type: Type.STRING },
          errors: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                type: { type: Type.STRING },
                original: { type: Type.STRING },
                suggestion: { type: Type.STRING },
                explanation: { type: Type.STRING }
              },
              required: ["type", "original", "suggestion", "explanation"]
            }
          },
          professionalRephrase: { type: Type.STRING }
        },
        required: ["originalText", "correctedText", "errors", "professionalRephrase"]
      }
    },
  });
  const resText = response.text || "{}";
  return JSON.parse(resText);
}

export async function generateVocabularyFlashcard(word: string): Promise<any> {
  const ai = getGeminiAI();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Provide details for the English word "${word}". 
    Include translation to Arabic, simple definition in English, a usage example, and difficulty level (A1-C2).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          word: { type: Type.STRING },
          translation: { type: Type.STRING },
          definition: { type: Type.STRING },
          example: { type: Type.STRING },
          level: { type: Type.STRING }
        },
        required: ["word", "translation", "definition", "example", "level"]
      }
    },
  });
  const text = response.text || "{}";
  return JSON.parse(text);
}

export async function generateImageForWord(word: string): Promise<string | null> {
  const ai = getGeminiAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: `A simple visual representation of the word "${word}" for English learning flashcards. High quality illustration on a clean white background.`,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates?.[0]?.content.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
}

export function encodeAudio(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function decodeAudio(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
