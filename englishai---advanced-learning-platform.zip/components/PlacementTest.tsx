
import React, { useState, useEffect } from 'react';
import { CheckCircle2, ChevronLeft, ChevronRight, Trophy, Loader2, BrainCircuit, HelpCircle, Layers } from 'lucide-react';
import { Level, Question } from '../types';
import { generatePlacementQuestions } from '../services/geminiService';

interface PlacementTestProps {
  onFinish?: (level: Level, score: number) => void;
}

const PlacementTest: React.FC<PlacementTestProps> = ({ onFinish }) => {
  const [questionCount, setQuestionCount] = useState<25 | 50 | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number | 'unknown'>>({});
  const [isFinished, setIsFinished] = useState(false);
  const [loadingQuestions, setLoadingQuestions] = useState(false);

  useEffect(() => {
    if (questionCount) {
      const fetchQuestions = async () => {
        setLoadingQuestions(true);
        try {
          const aiQuestions = await generatePlacementQuestions(questionCount);
          setQuestions(aiQuestions);
        } catch (error) {
          console.error("Failed to load AI questions", error);
        } finally {
          setLoadingQuestions(false);
        }
      };
      fetchQuestions();
    }
  }, [questionCount]);

  const handleSelect = (idx: number | 'unknown') => {
    setAnswers({ ...answers, [currentIdx]: idx });
  };

  const next = () => {
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setIsFinished(true);
    }
  };

  const prev = () => {
    if (currentIdx > 0) setCurrentIdx(currentIdx - 1);
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.correctAnswerIndex) score++;
    });
    return score;
  };

  if (!questionCount) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center animate-in fade-in zoom-in duration-500">
        <div className="w-20 h-20 bg-indigo-100 rounded-3xl flex items-center justify-center mx-auto mb-8 transform rotate-3 shadow-lg shadow-indigo-50">
          <Layers className="w-10 h-10 text-indigo-600" />
        </div>
        <h2 className="text-3xl font-extrabold text-slate-800 mb-4">اختر طول الاختبار</h2>
        <p className="text-slate-500 mb-10 text-lg">كلما زاد عدد الأسئلة، كانت النتيجة أكثر دقة</p>
        
        <div className="grid grid-cols-2 gap-6">
          <button 
            onClick={() => setQuestionCount(25)}
            className="group relative bg-white p-8 rounded-3xl border-2 border-slate-100 hover:border-indigo-600 transition-all text-center shadow-sm hover:shadow-xl"
          >
            <div className="text-4xl font-black text-indigo-600 mb-2">25</div>
            <div className="text-slate-500 font-bold">سؤالاً</div>
            <div className="text-xs text-slate-400 mt-2">اختبار سريع</div>
          </button>
          
          <button 
            onClick={() => setQuestionCount(50)}
            className="group relative bg-white p-8 rounded-3xl border-2 border-slate-100 hover:border-indigo-600 transition-all text-center shadow-sm hover:shadow-xl"
          >
            <div className="text-4xl font-black text-indigo-600 mb-2">50</div>
            <div className="text-slate-500 font-bold">سؤالاً</div>
            <div className="text-xs text-slate-400 mt-2">اختبار شامل (موصى به)</div>
          </button>
        </div>
      </div>
    );
  }

  if (loadingQuestions) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center">
        <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-8">
          <BrainCircuit className="w-12 h-12 text-indigo-600 animate-pulse" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-4">جاري إنشاء اختبار مخصص لك...</h2>
        <p className="text-slate-500 mb-8 font-medium">الذكاء الاصطناعي يصمم الآن {questionCount} سؤالاً متدرجة الصعوبة</p>
        <div className="flex justify-center">
          <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
        </div>
      </div>
    );
  }

  if (isFinished) {
    const score = calculateScore();
    const percentage = (score / questions.length) * 100;
    
    let level: Level = "A1";
    if (percentage > 90) level = "C2";
    else if (percentage > 80) level = "C1";
    else if (percentage > 65) level = "B2";
    else if (percentage > 45) level = "B1";
    else if (percentage > 25) level = "A2";

    return (
      <div className="max-w-2xl mx-auto bg-white rounded-3xl p-10 shadow-xl border border-indigo-50 text-center animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6 text-yellow-600">
          <Trophy className="w-12 h-12" />
        </div>
        <h2 className="text-3xl font-bold mb-4">أحسنت! انتهى الاختبار</h2>
        <p className="text-slate-600 mb-8 text-lg">بناءً على أدائك في {questions.length} سؤالاً، مستواك هو:</p>
        
        <div className="inline-block px-10 py-6 bg-indigo-600 text-white rounded-2xl text-4xl font-bold mb-8 shadow-lg shadow-indigo-200">
          {level}
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-right mb-10">
          <div className="bg-slate-50 p-4 rounded-xl">
            <p className="text-sm text-slate-500">معدل الدقة</p>
            <p className="text-xl font-bold">{Math.round(percentage)}%</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl">
            <p className="text-sm text-slate-500">الإجابات الصحيحة</p>
            <p className="text-xl font-bold text-green-600">{score}</p>
          </div>
        </div>

        <button 
          onClick={() => onFinish?.(level, score)}
          className="w-full bg-slate-900 text-white py-5 rounded-2xl font-bold hover:bg-slate-800 transition-colors shadow-lg"
        >
          حفظ النتيجة والبدء في التعلم
        </button>
      </div>
    );
  }

  const question = questions[currentIdx];
  const progress = ((currentIdx + 1) / questions.length) * 100;

  return (
    <div className="max-w-2xl mx-auto py-10">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4 text-sm font-bold">
          <div className="flex items-center gap-2 text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
            <span>السؤال {currentIdx + 1} من {questions.length}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-500">
            <span>صعوبة السؤال:</span>
            <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-black">{question?.difficulty}</span>
          </div>
        </div>
        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden shadow-inner">
          <div 
            className="h-full bg-indigo-500 transition-all duration-300 relative" 
            style={{ width: `${progress}%` }}
          >
            <div className="absolute top-0 right-0 bottom-0 w-4 bg-white/20 animate-pulse" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-8 shadow-xl border border-slate-100 mb-6 min-h-[420px] flex flex-col relative overflow-hidden">
         <div className="absolute top-0 right-0 p-4 opacity-5">
            <BrainCircuit className="w-32 h-32" />
         </div>
         
        <div className="mb-4 relative z-10">
          <span className="text-xs font-bold uppercase tracking-wider bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full">
            {question?.category || 'General'}
          </span>
        </div>
        
        <h3 className="text-2xl font-bold text-slate-800 mb-8 text-left leading-relaxed relative z-10" dir="ltr">
          {question?.text}
        </h3>
        
        <div className="space-y-3 mt-auto relative z-10">
          {question?.options.map((option, i) => (
            <button
              key={i}
              onClick={() => handleSelect(i)}
              className={`w-full p-4 text-left border-2 rounded-2xl transition-all flex justify-between items-center group ${
                answers[currentIdx] === i 
                  ? 'border-indigo-600 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-100 shadow-md' 
                  : 'border-slate-50 hover:border-indigo-200 hover:bg-slate-50 text-slate-700'
              }`}
              dir="ltr"
            >
              <span className="font-semibold text-lg">{option}</span>
              {answers[currentIdx] === i && <CheckCircle2 className="w-6 h-6 text-indigo-600" />}
            </button>
          ))}
          
          <button
            onClick={() => handleSelect('unknown')}
            className={`w-full p-4 text-right border-2 border-dashed rounded-2xl transition-all flex justify-between items-center ${
              answers[currentIdx] === 'unknown'
                ? 'border-amber-500 bg-amber-50 text-amber-700 ring-2 ring-amber-100'
                : 'border-slate-100 text-slate-400 hover:bg-slate-50'
            }`}
          >
            <span className="font-bold flex items-center gap-2">
              <HelpCircle className="w-5 h-5" />
              لا أعرف الإجابة
            </span>
            {answers[currentIdx] === 'unknown' && <CheckCircle2 className="w-6 h-6 text-amber-500" />}
          </button>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={prev}
          disabled={currentIdx === 0}
          className="flex-1 flex items-center justify-center gap-2 py-5 border-2 border-slate-200 rounded-2xl font-bold text-slate-600 disabled:opacity-30 hover:bg-slate-50 transition-all shadow-sm"
        >
          <ChevronRight className="w-5 h-5" />
          السابق
        </button>
        <button
          onClick={next}
          disabled={answers[currentIdx] === undefined}
          className="flex-[2] flex items-center justify-center gap-2 py-5 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-100 disabled:opacity-50 hover:bg-indigo-700 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
        >
          {currentIdx === questions.length - 1 ? 'إنهاء الاختبار' : 'التالي'}
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default PlacementTest;
