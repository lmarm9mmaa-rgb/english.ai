
import React, { useState, useEffect } from 'react';
import { Send, CheckCircle, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import { correctWriting } from '../services/geminiService';
import { WritingCorrection } from '../types';
import { db } from '../services/dbService';

interface WritingLabProps {
  userEmail?: string;
}

const WritingLab: React.FC<WritingLabProps> = ({ userEmail }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<WritingCorrection | null>(null);

  // Restore draft on mount
  useEffect(() => {
    if (userEmail) {
      const savedDraft = db.getWritingDraft(userEmail);
      if (savedDraft) setInput(savedDraft);
    }
  }, [userEmail]);

  // Save draft whenever input changes
  useEffect(() => {
    if (userEmail) {
      db.saveWritingDraft(userEmail, input);
    }
  }, [input, userEmail]);

  const handleSubmit = async () => {
    if (!input.trim()) return;
    setIsLoading(true);
    try {
      const correction = await correctWriting(input);
      setResult(correction);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
      <div className="space-y-6">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
          <label className="block text-lg font-bold mb-4 text-slate-800">اكتب موضوعاً بالإنجليزية:</label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-64 p-4 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 transition-all text-left resize-none"
            dir="ltr"
            placeholder="Write something here... (e.g., Talk about your last vacation)"
          ></textarea>
          
          <div className="mt-4 flex justify-between items-center">
            <span className="text-sm text-slate-500">{input.length} حرف</span>
            <button
              onClick={handleSubmit}
              disabled={isLoading || !input.trim()}
              className="flex items-center gap-2 bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50"
            >
              {isLoading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              تحليل النص
            </button>
          </div>
        </div>

        <div className="bg-indigo-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
          <Sparkles className="absolute top-[-10px] left-[-10px] w-24 h-24 text-indigo-800 opacity-50" />
          <div className="relative z-10">
            <h3 className="text-xl font-bold mb-2">نصيحة ذكية</h3>
            <p className="text-indigo-100 leading-relaxed">
              استخدم كلمات ربط متنوعة مثل "Furthermore" و "Moreover" لجعل كتابتك تبدو أكثر احترافية وأكاديمية.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {!result && !isLoading && (
          <div className="bg-slate-100 border-2 border-dashed border-slate-200 rounded-3xl h-[500px] flex flex-col items-center justify-center p-8 text-center text-slate-400">
            <AlertCircle className="w-16 h-16 mb-4 opacity-50" />
            <p className="text-lg">اكتب نصك في الجهة المقابلة لعرض التحليل الذكي هنا</p>
          </div>
        )}

        {isLoading && (
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 h-[500px] flex flex-col items-center justify-center animate-pulse">
            <div className="w-12 h-12 bg-indigo-100 rounded-full mb-4 flex items-center justify-center">
              <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
            </div>
            <p className="text-slate-600 font-medium">جاري تحليل الأخطاء وتقديم البدائل...</p>
          </div>
        )}

        {result && !isLoading && (
          <div className="animate-in fade-in slide-in-from-left-4 duration-500 space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <CheckCircle className="text-green-500 w-5 h-5" />
                التصحيح المقترح:
              </h3>
              <p className="text-slate-800 bg-slate-50 p-4 rounded-xl leading-relaxed text-left font-medium" dir="ltr">
                {result.correctedText}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Sparkles className="text-amber-500 w-5 h-5" />
                إعادة صياغة احترافية:
              </h3>
              <p className="text-slate-800 bg-indigo-50 p-4 rounded-xl leading-relaxed text-left italic" dir="ltr">
                {result.professionalRephrase}
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="font-bold text-slate-700 px-2">الأخطاء المكتشفة ({result.errors.length}):</h3>
              {result.errors.map((error, idx) => (
                <div key={idx} className="bg-white p-4 rounded-2xl border-r-4 border-red-500 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-red-500 px-2 py-1 bg-red-50 rounded">
                      {error.type === 'grammar' ? 'قواعد' : error.type === 'spelling' ? 'إملاء' : 'أسلوب'}
                    </span>
                    <span className="text-sm font-medium text-slate-400 line-through" dir="ltr">{error.original}</span>
                  </div>
                  <p className="text-indigo-600 font-bold mb-1" dir="ltr">→ {error.suggestion}</p>
                  <p className="text-sm text-slate-600">{error.explanation}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WritingLab;
