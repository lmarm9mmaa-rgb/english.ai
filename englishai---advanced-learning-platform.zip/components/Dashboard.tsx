
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area
} from 'recharts';
import { 
  Trophy, 
  Flame, 
  Target, 
  TrendingUp, 
  Play,
  ArrowUpRight,
  Zap
} from 'lucide-react';
import { UserProfile, Word } from '../types';

interface DashboardProps {
  user: UserProfile | null;
}

const activityData = [
  { name: 'السبت', value: 45 },
  { name: 'الأحد', value: 30 },
  { name: 'الاثنين', value: 60 },
  { name: 'الثلاثاء', value: 50 },
  { name: 'الأربعاء', value: 80 },
  { name: 'الخميس', value: 65 },
  { name: 'الجمعة', value: 90 },
];

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  if (!user) return null;

  // Get real vocab count
  const words: Word[] = JSON.parse(localStorage.getItem('vocab_words') || '[]');
  const wordCount = words.length;

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-l from-indigo-600 to-indigo-800 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl shadow-indigo-200">
        <div className="relative z-10 max-w-2xl text-right">
          <h2 className="text-3xl font-bold mb-4">أهلاً بك مجدداً، {user.name}! 👋</h2>
          <p className="text-indigo-100 text-lg mb-8 leading-relaxed">
            مرحباً بك في رحلتك التعليمية. مستواك الحالي هو {user.level}. يمكنك البدء الآن بإنشاء خطة مذاكرة مخصصة أو مراجعة كلماتك.
          </p>
          <div className="flex gap-4">
             <button className="bg-white text-indigo-700 px-8 py-4 rounded-2xl font-bold flex items-center gap-3 hover:bg-indigo-50 transition-all shadow-lg">
              <Play className="w-5 h-5 fill-current" />
              متابعة المذاكرة
            </button>
          </div>
        </div>
        <Zap className="absolute left-[-20px] bottom-[-20px] w-64 h-64 text-white opacity-10 rotate-12" />
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'نقاط الخبرة XP', value: `${user.xp || 0} نقطة`, icon: Zap, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: 'المستوى الحالي', value: user.level, icon: Target, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: 'كلمات مكتسبة', value: `${wordCount} كلمة`, icon: Trophy, color: 'text-yellow-600', bg: 'bg-yellow-50' },
          { label: 'أيام التعلم', value: '1 يوم', icon: Flame, color: 'text-orange-500', bg: 'bg-orange-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4 text-right">
            <div className={`${stat.bg} ${stat.color} p-4 rounded-2xl`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
              <p className="text-xl font-bold text-slate-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Weekly Activity Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex justify-between items-center mb-8">
            <div className="text-right">
              <h3 className="text-xl font-bold text-slate-800">نشاط المذاكرة</h3>
              <p className="text-sm text-slate-500 font-medium">الوقت المستغرق بالدقائق يومياً</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="value" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Suggested Tasks */}
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold text-slate-800 mb-6 text-right">مهام مقترحة لك</h3>
          <div className="space-y-4">
            {[
              { title: 'ممارسة المحادثة', subtitle: `مستوى ${user.level} - 10 دقائق`, points: '+50 XP', icon: ArrowUpRight },
              { title: 'اختبار مفردات جديد', subtitle: 'أضف 5 كلمات جديدة', points: '+30 XP', icon: ArrowUpRight },
              { title: 'إكمال خطة المذاكرة', subtitle: 'مهام الأسبوع الأول', points: '+100 XP', icon: ArrowUpRight },
            ].map((task, i) => (
              <button key={i} className="w-full flex items-center justify-between p-4 rounded-2xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-700 transition-all group">
                <div className="flex items-center gap-4 text-right">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm group-hover:text-indigo-600">
                    <task.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-800 group-hover:text-indigo-700">{task.title}</p>
                    <p className="text-xs text-slate-500">{task.subtitle}</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-indigo-600 bg-white px-3 py-1 rounded-full shadow-sm">{task.points}</span>
              </button>
            ))}
          </div>
          <button className="w-full mt-6 py-4 border-2 border-slate-100 text-slate-500 font-bold rounded-2xl hover:bg-slate-50 transition-all">
            عرض كل المهام
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
