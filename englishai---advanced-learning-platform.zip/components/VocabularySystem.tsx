
import React, { useState, useEffect } from 'react';
import { 
  Volume2, 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight, 
  Plus,
  BrainCircuit,
  Loader2
} from 'lucide-react';
import { Word } from '../types';
import { generateVocabularyFlashcard, generateImageForWord } from '../services/geminiService';

const VocabularySystem: React.FC = () => {
  const [words, setWords] = useState<Word[]>(() => {
    const saved = localStorage.getItem('vocab_words');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [newWordInput, setNewWordInput] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    localStorage.setItem('vocab_words', JSON.stringify(words));
  }, [words]);

  const handleAddWord = async () => {
    if (!newWordInput.trim()) return;
    setIsAdding(true);
    try {
      const details = await generateVocabularyFlashcard(newWordInput);
      const img = await generateImageForWord(newWordInput);
      
      const newWord: Word = {
        id: Date.now().toString(),
        word: details.word,
        translation: details.translation,
        definition: details.definition,
        pronunciation_us: '', 
        pronunciation_uk: '',
        example: details.example,
        level: details.level as any,
        nextReview: Date.now(),
        interval: 1,
        difficulty: 'medium',
        image: img || undefined
      };
      setWords([newWord, ...words]);
      setNewWordInput('');
      setCurrentIdx(0);
      setIsFlipped(false);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAdding(false);
    }
  };

  const handleDifficulty = (difficulty: 'easy' | 'medium' | 'hard') => {
    const updatedWords = [...words];
    const word = updatedWords[currentIdx];
    
    // Simple Spaced Repetition Logic
    let newInterval = word.interval;
    if (difficulty === 'easy') newInterval *= 2;
    else if (difficulty === 'hard') newInterval = Math.max(1, Math.floor(newInterval / 2));
    
    word.interval = newInterval;
    word.nextReview = Date.now() + (newInterval * 24 * 60 * 60 * 1000);
    word.difficulty = difficulty;
    
    setWords(updatedWords);
    setIsFlipped(false);
    if (currentIdx < words.length - 1) setCurrentIdx(currentIdx + 1);
  };

  const currentWord = words[currentIdx];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Search & Add */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <input
            type="text"
            value={newWordInput}
            onChange={(e) => setNewWordInput(e.target.value)}
            placeholder="أضف كلمة جديدة للتعلم (مثال: Resilient)"
            className="w-full px-6 py-4 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 focus:ring-0 transition-all text-right"
          />
        </div>
        <button
          onClick={handleAddWord}
          disabled={isAdding || !newWordInput}
          className="bg-indigo-600 text-white px-8 rounded-2xl font-bold flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-100"
        >
          {isAdding ? <Loader2 className="w-5 h-5 animate-spin" /> : <Plus className="w-5 h-5" />}
          إضافة
        </button>
      </div>

      {words.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-slate-200">
          <BrainCircuit className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-slate-800 mb-2">لا توجد كلمات حالياً</h3>
          <p className="text-slate-500">ابدأ بإضافة كلمات جديدة لبناء بنك المفردات الخاص بك باستخدام الذكاء الاصطناعي</p>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Progress Info */}
          <div className="flex justify-between items-end">
            <div>
              <h3 className="text-2xl font-bold text-slate-800">بطاقات المراجعة</h3>
              <p className="text-slate-500">تم مراجعة {currentIdx} من {words.length} كلمات اليوم</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setCurrentIdx(Math.max(0, currentIdx - 1))}
                className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
              <button 
                onClick={() => setCurrentIdx(Math.min(words.length - 1, currentIdx + 1))}
                className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Flashcard */}
          <div className="perspective-1000">
            <div 
              onClick={() => setIsFlipped(!isFlipped)}
              className={`relative w-full h-[550px] transition-all duration-500 transform-style-3d cursor-pointer ${isFlipped ? 'rotate-y-180' : ''}`}
            >
              {/* Front */}
              <div className="absolute inset-0 backface-hidden bg-white rounded-[2.5rem] shadow-xl border border-indigo-50 flex flex-col items-center justify-center p-8 text-center">
                <div className="bg-indigo-100 text-indigo-700 px-4 py-1 rounded-full text-sm font-bold mb-6">
                  {currentWord.level}
                </div>
                
                {currentWord.image && (
                  <div className="w-48 h-48 mb-6 rounded-2xl overflow-hidden bg-slate-50 flex items-center justify-center border border-slate-100">
                    <img src={currentWord.image} alt={currentWord.word} className="w-full h-full object-contain" />
                  </div>
                )}
                
                <h2 className="text-5xl font-bold text-slate-800 mb-4" dir="ltr">{currentWord.word}</h2>
                <div className="flex gap-4 mb-8">
                  <button className="flex items-center gap-2 text-indigo-600 font-semibold hover:bg-indigo-50 px-3 py-1 rounded-lg transition-colors">
                    <Volume2 className="w-5 h-5" />
                    US
                  </button>
                  <button className="flex items-center gap-2 text-indigo-600 font-semibold hover:bg-indigo-50 px-3 py-1 rounded-lg transition-colors">
                    <Volume2 className="w-5 h-5" />
                    UK
                  </button>
                </div>
                <p className="text-slate-400 text-sm mt-auto">اضغط للقلب وعرض المعنى والمثال</p>
              </div>

              {/* Back */}
              <div className="absolute inset-0 backface-hidden bg-white rounded-[2.5rem] shadow-xl border border-indigo-50 flex flex-col p-8 rotate-y-180 overflow-y-auto">
                <div className="flex justify-between items-start mb-6">
                  <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">تعريف</span>
                  <RotateCcw className="w-5 h-5 text-slate-300" />
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-3xl font-bold text-indigo-600 mb-2">{currentWord.translation}</h3>
                    <p className="text-slate-700 font-medium text-lg leading-relaxed text-left" dir="ltr">
                      {currentWord.definition}
                    </p>
                  </div>

                  <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                    <h4 className="text-sm font-bold text-slate-400 mb-2">مثال:</h4>
                    <p className="text-slate-800 text-lg italic leading-relaxed text-left" dir="ltr">
                      "{currentWord.example}"
                    </p>
                  </div>
                </div>

                <div className="mt-auto pt-8 flex gap-3">
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDifficulty('easy'); }}
                    className="flex-1 bg-green-50 text-green-700 py-3 rounded-xl font-bold border-2 border-green-100 hover:bg-green-100 transition-all flex items-center justify-center gap-2"
                  >
                    سهلة <span className="text-xs opacity-60">(14 يوم)</span>
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDifficulty('medium'); }}
                    className="flex-1 bg-amber-50 text-amber-700 py-3 rounded-xl font-bold border-2 border-amber-100 hover:bg-amber-100 transition-all flex items-center justify-center gap-2"
                  >
                    متوسطة <span className="text-xs opacity-60">(4 أيام)</span>
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDifficulty('hard'); }}
                    className="flex-1 bg-red-50 text-red-700 py-3 rounded-xl font-bold border-2 border-red-100 hover:bg-red-100 transition-all flex items-center justify-center gap-2"
                  >
                    صعبة <span className="text-xs opacity-60">(1 يوم)</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .perspective-1000 { perspective: 1000px; }
        .backface-hidden { backface-visibility: hidden; }
        .transform-style-3d { transform-style: preserve-3d; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
};

export default VocabularySystem;
