
import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Download, 
  RefreshCw, 
  CheckCircle2, 
  Clock, 
  ExternalLink, 
  BookOpen, 
  MessageSquare, 
  PenTool, 
  Headphones,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { generateStudyPlan } from '../services/geminiService';
import { StudyPlan, Level } from '../types';

interface StudyPlanProps {
  currentLevel?: Level;
}

const StudyPlanGenerator: React.FC<StudyPlanProps> = ({ currentLevel: initialLevel }) => {
  const [currentLevel, setCurrentLevel] = useState<string>(initialLevel || 'B1');
  const [targetLevel, setTargetLevel] = useState('B2');
  const [dailyTime, setDailyTime] = useState('1 hour');
  const [isLoading, setIsLoading] = useState(false);
  const [plan, setPlan] = useState<StudyPlan | null>(() => {
    const saved = localStorage.getItem('current_study_plan');
    return saved ? JSON.parse(saved) : null;
  });
  const [expandedPhase, setExpandedPhase] = useState<number | null>(1);

  useEffect(() => {
    if (initialLevel) setCurrentLevel(initialLevel);
  }, [initialLevel]);

  useEffect(() => {
    if (plan) {
      localStorage.setItem('current_study_plan', JSON.stringify(plan));
    }
  }, [plan]);

  const handleGenerate = async () => {
    setIsLoading(true);
    try {
      const data = await generateStudyPlan(currentLevel, targetLevel, dailyTime);
      setPlan(data);
      setExpandedPhase(1);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-700">
      {/* Config Form */}
      <div className="bg-white rounded-[2.5rem] p-10 shadow-xl shadow-indigo-50 border border-slate-100">
        <h3 className="text-3xl font-extrabold mb-2 text-slate-800">صانع خطة الـ 6 أشهر</h3>
        <p className="text-slate-500 mb-10 text-lg">خطة متكاملة وشاملة لكل مهارات اللغة الإنجليزية مع المصادر والمواقيت</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-500 px-1 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-indigo-400" />
              مستواك الحالي
            </label>
            <select 
              value={currentLevel}
              onChange={(e) => setCurrentLevel(e.target.value)}
              className="w-full bg-slate-50 border-2 border-transparent hover:border-slate-100 rounded-2xl font-bold p-5 focus:bg-white focus:border-indigo-500 focus:ring-0 transition-all text-lg"
            >
              {['A1', 'A2', 'B1', 'B2', 'C1'].map(l => <option key={l} value={l}>{l} English</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-500 px-1 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              المستوى المستهدف
            </label>
            <select 
              value={targetLevel}
              onChange={(e) => setTargetLevel(e.target.value)}
              className="w-full bg-slate-50 border-2 border-transparent hover:border-slate-100 rounded-2xl font-bold p-5 focus:bg-white focus:border-indigo-500 focus:ring-0 transition-all text-lg"
            >
              {['A2', 'B1', 'B2', 'C1', 'C2'].map(l => <option key={l} value={l}>{l} Mastery</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-500 px-1 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-orange-400" />
              الوقت اليومي المتاح
            </label>
            <select 
              value={dailyTime}
              onChange={(e) => setDailyTime(e.target.value)}
              className="w-full bg-slate-50 border-2 border-transparent hover:border-slate-100 rounded-2xl font-bold p-5 focus:bg-white focus:border-indigo-500 focus:ring-0 transition-all text-lg"
            >
              <option value="30 minutes">30 دقيقة</option>
              <option value="1 hour">ساعة واحدة</option>
              <option value="2 hours">ساعتين (مكثف)</option>
              <option value="4 hours">4 ساعات (فائق)</option>
            </select>
          </div>
        </div>
        
        <button 
          onClick={handleGenerate}
          disabled={isLoading}
          className="w-full bg-indigo-600 text-white py-6 rounded-[2rem] font-bold text-xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-3 transform hover:scale-[1.01] active:scale-95"
        >
          {isLoading ? (
            <><RefreshCw className="w-7 h-7 animate-spin" /> جاري تخطيط 6 أشهر من النجاح...</>
          ) : (
            <><Calendar className="w-7 h-7" /> تصميم خطة الـ 6 أشهر الآن</>
          )}
        </button>
      </div>

      {/* Results */}
      {plan && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-500 pb-12">
          <div className="flex flex-col sm:flex-row justify-between items-center px-4 gap-4">
            <h4 className="text-2xl font-black text-slate-800">خارطة الطريق لـ {plan.duration}</h4>
            <button className="flex items-center gap-2 text-white font-bold bg-slate-900 px-8 py-4 rounded-2xl hover:bg-slate-800 transition-all shadow-lg">
              <Download className="w-5 h-5" />
              تحميل الجدول كاملاً (PDF)
            </button>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {plan.phases.map((phase, idx) => (
              <div key={idx} className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
                <button 
                  onClick={() => setExpandedPhase(expandedPhase === phase.month ? null : phase.month)}
                  className={`w-full p-8 flex items-center justify-between text-right transition-all ${expandedPhase === phase.month ? 'bg-indigo-50' : 'hover:bg-slate-50'}`}
                >
                  <div className="flex items-center gap-6">
                    <div className="bg-indigo-600 text-white w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black shadow-lg shadow-indigo-100">
                      {phase.month}
                    </div>
                    <div>
                      <h5 className="text-xl font-bold text-slate-800">المرحلة {phase.month}: {phase.goal}</h5>
                      <p className="text-slate-500 text-sm font-medium">يتضمن {phase.weeks.length} أسابيع تدريبية مكثفة</p>
                    </div>
                  </div>
                  {expandedPhase === phase.month ? <ChevronUp className="w-6 h-6 text-indigo-400" /> : <ChevronDown className="w-6 h-6 text-slate-300" />}
                </button>

                {expandedPhase === phase.month && (
                  <div className="p-8 space-y-10 animate-in fade-in slide-in-from-top-4 duration-300">
                    {phase.weeks.map((week, widx) => (
                      <div key={widx} className="space-y-8">
                        {/* Routine Header */}
                        <div className="flex flex-wrap items-center gap-4 border-b border-slate-100 pb-4">
                          <h6 className="text-lg font-black text-indigo-600">الأسبوع {week.week}: الروتين اليومي</h6>
                          <div className="flex gap-2 ml-auto">
                            <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                              <Headphones className="w-3 h-3" /> استماع: {week.dailyRoutine.listening} د
                            </span>
                            <span className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                              <BookOpen className="w-3 h-3" /> قراءة: {week.dailyRoutine.reading} د
                            </span>
                            <span className="bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                              <PenTool className="w-3 h-3" /> كتابة: {week.dailyRoutine.writing} د
                            </span>
                            <span className="bg-orange-50 text-orange-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                              <MessageSquare className="w-3 h-3" /> تحدث: {week.dailyRoutine.speaking} د
                            </span>
                          </div>
                        </div>

                        {/* Resources */}
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {week.resources.map((res, ridx) => (
                            <div key={ridx} className="bg-slate-50 p-5 rounded-2xl border border-slate-200 group hover:border-indigo-300 transition-all">
                              <div className="flex items-center justify-between mb-3">
                                <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${res.type === 'internal' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                                  {res.type === 'internal' ? 'داخل المنصة' : 'مصدر خارجي'}
                                </span>
                                {res.type === 'external' && <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-indigo-500" />}
                              </div>
                              <h6 className="font-bold text-slate-800 mb-1">{res.name}</h6>
                              <p className="text-xs text-slate-500 leading-relaxed">{res.description}</p>
                            </div>
                          ))}
                        </div>

                        {/* Tasks */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {week.tasks.map((task, tidx) => (
                            <div key={tidx} className="bg-white p-5 rounded-2xl border-2 border-slate-50 flex items-start gap-4 hover:shadow-md transition-shadow">
                              <div className="bg-indigo-50 p-2 rounded-xl text-indigo-600">
                                <CheckCircle2 className="w-5 h-5" />
                              </div>
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-black text-slate-800">{task.day}</span>
                                  <span className="text-[10px] bg-slate-100 text-slate-400 px-2 py-0.5 rounded-full font-bold">{task.activity}</span>
                                </div>
                                <p className="text-sm text-slate-600 leading-relaxed">{task.description}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default StudyPlanGenerator;
