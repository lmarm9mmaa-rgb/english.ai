
export type Level = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'Unknown';

export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  category: 'grammar' | 'vocabulary' | 'reading';
  difficulty: Level; // Added difficulty field
}

export interface UserProfile {
  email: string;
  password?: string;
  name: string;
  level: Level;
  xp: number;
  joinedAt: number;
  isOnboarded: boolean;
  hasTakenPlacementTest: boolean;
  testScore?: number;
}

export interface StudyPlan {
  duration: string;
  phases: {
    month: number;
    goal: string;
    weeks: {
      week: number;
      dailyRoutine: {
        listening: number; // minutes
        reading: number;
        writing: number;
        speaking: number;
      };
      resources: {
        name: string;
        type: 'internal' | 'external';
        url?: string;
        description: string;
      }[];
      tasks: {
        day: string;
        activity: string;
        description: string;
      }[];
    }[];
  }[];
}

export interface WritingCorrection {
  originalText: string;
  correctedText: string;
  errors: {
    type: 'grammar' | 'spelling' | 'punctuation' | 'style';
    original: string;
    suggestion: string;
    explanation: string;
  }[];
  professionalRephrase: string;
}

export interface Word {
  id: string;
  word: string;
  translation: string;
  definition: string;
  pronunciation_us: string;
  pronunciation_uk: string;
  example: string;
  level: Level;
  nextReview: number;
  interval: number;
  difficulty: 'easy' | 'medium' | 'hard';
  image?: string;
}
